{{#unless feature_image}}
<div class="post-classic-media post-quote-wrap">
    <div class="post-classic-quote">
        <p class="post-classic-title">{{excerpt words="15"}}</p>
    </div>    
</div>